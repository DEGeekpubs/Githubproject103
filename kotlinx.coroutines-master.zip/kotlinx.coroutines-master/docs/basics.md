The documentation has been moved to the [https://kotlinlang.org/docs/coroutines-basics.html](https://kotlinlang.org/docs/coroutines-basics.html) page.

To edit the documentation, open the [topics/coroutines-basics.md](topics/coroutines-basics.md) page.
