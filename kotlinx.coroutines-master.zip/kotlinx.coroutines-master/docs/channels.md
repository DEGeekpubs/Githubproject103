The documentation has been moved to the [https://kotlinlang.org/docs/channels.html](https://kotlinlang.org/docs/channels.html) page.

To edit the documentation, open the [topics/channels.md](topics/channels.md) page.