The documentation has been moved to the [https://kotlinlang.org/docs/composing-suspending-functions.html](https://kotlinlang.org/docs/composing-suspending-functions.html) page.

To edit the documentation, open the [topics/composing-suspending-functions.md](topics/composing-suspending-functions.md) page.