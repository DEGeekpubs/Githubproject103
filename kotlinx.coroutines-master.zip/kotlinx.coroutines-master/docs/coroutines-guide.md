The documentation has been moved to the [https://kotlinlang.org/docs/coroutines-guide.html](https://kotlinlang.org/docs/coroutines-guide.html) page.

To edit the documentation, open the [topics/coroutines-guide.md](topics/coroutines-guide.md) page.