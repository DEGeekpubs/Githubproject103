The documentation has been moved to the [https://kotlinlang.org/docs/exception-handling.html](https://kotlinlang.org/docs/exception-handling.html) page.

To edit the documentation, open the [topics/exception-handling.md](topics/exception-handling.md) page.