The documentation has been moved to the [https://kotlinlang.org/docs/flow.html](https://kotlinlang.org/docs/flow.html) page.

To edit the documentation, open the [topics/flow.md](topics/flow.md) page.