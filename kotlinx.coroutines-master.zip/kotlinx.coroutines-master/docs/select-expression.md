The documentation has been moved to the [https://kotlinlang.org/docs/select-expression.html](https://kotlinlang.org/docs/select-expression.html) page.

To edit the documentation, open the [topics/select-expression.md](topics/select-expression.md) page.