# Customize Dokka's HTML. 
To customize Dokka's HTML output, place a file in this folder.
Dokka will find a template file there. If the file is not found, a default one will be used.
This folder is defined by the templatesDir property.