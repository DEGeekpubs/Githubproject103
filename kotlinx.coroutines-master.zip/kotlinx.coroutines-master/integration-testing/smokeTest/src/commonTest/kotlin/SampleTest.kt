import kotlinx.coroutines.test.*
import kotlin.test.*

class SampleTest {
    @Test
    fun test() = runTest {
        doWorld()
    }
}
