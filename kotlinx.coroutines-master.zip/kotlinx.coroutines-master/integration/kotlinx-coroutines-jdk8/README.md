# Stub module

Stub module for backwards compatibility. Since 1.7.0, this module was merged with core.
