@SuppressWarnings("JavaModuleNaming")
module kotlinx.coroutines.jdk8 {
}
