module kotlinx.coroutines.slf4j {
    requires kotlin.stdlib;
    requires kotlinx.coroutines.core;
    requires org.slf4j;

    exports kotlinx.coroutines.slf4j;
}
