package kotlinx.coroutines

internal actual abstract class SchedulerTask : Runnable
