package kotlinx.coroutines.internal

internal actual fun systemProp(propertyName: String): String? = null
