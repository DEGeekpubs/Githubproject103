package kotlinx.coroutines.internal

import kotlin.coroutines.*

internal actual fun threadContextElements(context: CoroutineContext): Any = 0
