package kotlinx.coroutines

import kotlinx.coroutines.scheduling.*

internal actual typealias SchedulerTask = Task
